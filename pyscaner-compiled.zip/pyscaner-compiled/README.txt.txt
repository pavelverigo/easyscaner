You need Python 3.9+ version to install it. (you can use 'py -0p' to see all versions, and 'py' to run main one)

Run install.bat to install package.
Alternatively, to install our package globally, open command line inside pyscaner directory and call 'pip install -e .'.

NOTE: Do not delete 'src' and this folder after installation

To run example, use 'python <file_name>.py'.
You can find all python samples in 'samples/python/' in project folder.

Also in this folder there is image, explaining how to add process to Scaner.