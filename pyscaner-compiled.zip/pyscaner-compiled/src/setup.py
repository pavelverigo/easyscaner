from setuptools import setup

setup(
    name='pyscaner',
    description='Python bindings to EasyScaner library.',
    version='0.5.0',
    py_modules=['pyscaner'],
)